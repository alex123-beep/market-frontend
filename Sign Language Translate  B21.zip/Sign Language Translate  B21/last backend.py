from flask import Flask, render_template, Response, jsonify, request, send_file
from flask_cors import CORS
from gtts import gTTS
from file_lock import safe_read_json, safe_write_json
import cv2
import pickle
import numpy as np
import mediapipe as mp
import time
import os
import tempfile
import json
import io
import speech_recognition as sr
from pydub import AudioSegment
from pydub.utils import which

app = Flask(__name__)
CORS(app)

def load_users():
    return safe_read_json('users.json')

def save_users(users):
    safe_write_json('users.json', users)

@app.route('/api/register', methods=['POST'])
def register_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    
    if not username or not password or not email:
        return jsonify({'error': 'جميع الحقول مطلوبة'}), 400
    
    users_data = load_users()
    
    # Check if username exists in the users section
    if username in users_data.get('users', {}):
        return jsonify({'error': 'اسم المستخدم موجود بالفعل'}), 400
    
    # Make sure 'users' key exists
    if 'users' not in users_data:
        users_data['users'] = {}
    
    # Generate a new ID (you can modify this logic if needed)
    new_id = str(len(users_data['users']) + 1)
    
    # Add the new user with proper structure
    users_data['users'][username] = {
        'password': password,
        'email': email,
        'id': new_id
    }
    
    # Save the updated data
    save_users(users_data)
    return jsonify({'message': 'تم التسجيل بنجاح'}), 200

@app.route('/api/login', methods=['POST'])
def login_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    print(f"Login attempt - Username: {username}")  # للتشخيص
    
    if not username or not password:
        return jsonify({'error': 'يرجى إدخال اسم المستخدم وكلمة المرور'}), 400
    users_data = load_users()
    print(f"Loaded users: {users_data}")  # للتشخيص
    
    user = users_data.get('users', {}).get(username)
    print(f"Found user: {user}")  # للتشخيص
    
    if user is None:
        return jsonify({'error': 'اسم المستخدم غير موجود'}), 401
    
    if user['password'] != password:
        return jsonify({'error': 'كلمة المرور غير صحيحة'}), 401
    
    # Add user to online users list
    if add_user_to_online(username):
        return jsonify({'message': 'تم تسجيل الدخول بنجاح', 'username': username}), 200
    else:
        return jsonify({'error': 'حدث خطأ أثناء تسجيل الدخول'}), 500

# Initialize the speech recognizer
recognizer = sr.Recognizer()

# Add global variables to store predictions and mode
current_prediction = None
last_prediction = None
had_no_hand = False
prediction_start_time = None  # Track when a prediction started
confirmed_prediction = None  # Store the confirmed prediction
is_sign_mode = True  # Track if we're in sign language mode

@app.route('/set_mode', methods=['POST'])
def set_mode():
    global is_sign_mode
    data = request.get_json()
    is_sign_mode = data.get('mode') == 'sign'
    return jsonify({'success': True})

# Function has been removed as it's not being used

@app.route('/')
def index():
    return render_template('login.html')
@app.route('/login')
def login():
    return render_template('login.html')
@app.route('/register')
def register():
    return render_template('register.html')
@app.route('/Home')
def Home():
    return render_template('index.html')

@app.route('/video_call')
def video_call():
    return render_template('video_call.html')

# Route to serve the video feed
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']
labels_dict = {
    0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J',
    10: 'K', 11: 'L', 12: 'M', 13: 'N', 14: 'O', 15: 'P', 16: 'Q', 17: 'R', 18: 'S',
    19: 'T', 20: 'U', 21: 'V', 22: 'W', 23: 'X', 24: 'Y', 25: 'Z',
    26: '0', 27: '1', 28: '2', 29: '3', 30: '4', 31: '5', 32: '6', 33: '7', 34: '8',
    35: '9', 36: ' '
}

# Initialize MediaPipe components
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5)

def generate_frames():
    global current_prediction, last_prediction, had_no_hand, prediction_start_time, confirmed_prediction, is_sign_mode
    
    # Try to open the default camera (usually the built-in webcam)
    cap = cv2.VideoCapture(0)
    
    # If the default camera fails, try the external camera
    if not cap.isOpened():
        cap = cv2.VideoCapture(1)
        
    # If both cameras fail, try other indices
    if not cap.isOpened():
        for i in range(2, 10):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                break
                
    # If still no camera is opened, return error
    if not cap.isOpened():
        print("Error: Could not open any camera")
        return
        
    try:
        while True:
            success, frame = cap.read()
            if not success:
                print("Error: Could not read frame")
                break
                
            frame = cv2.flip(frame, 1)
            
            # Only process hand detection and recognition in sign mode
            if is_sign_mode:
                data_aux = []
                x_ = []
                y_ = []
                
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = hands.process(frame_rgb)
                
                if not results.multi_hand_landmarks:
                    had_no_hand = True
                    prediction_start_time = None
                    last_prediction = None
                    current_prediction = None
                
                if results.multi_hand_landmarks:
                    for hand_landmarks in results.multi_hand_landmarks:
                        # Draw hand landmarks
                        mp_drawing.draw_landmarks(
                            frame,
                            hand_landmarks,
                            mp_hands.HAND_CONNECTIONS,
                            mp_drawing_styles.get_default_hand_landmarks_style(),
                            mp_drawing_styles.get_default_hand_connections_style()
                        )
                        
                        # Process landmarks for prediction
                        for landmark in hand_landmarks.landmark:
                            x_.append(landmark.x)
                            y_.append(landmark.y)
                        
                        for landmark in hand_landmarks.landmark:
                            data_aux.append(landmark.x - min(x_))
                            data_aux.append(landmark.y - min(y_))
                        
                        # Make prediction if we have enough features
                        if len(data_aux) == 42:
                            try:
                                prediction = model.predict([np.asarray(data_aux)])
                                predicted_character = labels_dict[int(prediction[0])]
                                
                                if predicted_character != last_prediction:
                                    prediction_start_time = time.time()
                                    last_prediction = predicted_character
                                    confirmed_prediction = None
                                time_sec = 2
                                time_left = time_sec - (time.time() - prediction_start_time) if prediction_start_time else time_sec
                                
                                if time_left <= 0 and confirmed_prediction != predicted_character:
                                    confirmed_prediction = predicted_character
                                    current_prediction = {
                                        'character': predicted_character,
                                        'time_left': 0,
                                        'is_confirmed': True,
                                        'confidence': 1.0
                                    }
                                elif confirmed_prediction != predicted_character:
                                    progress = 1.0 - time_left
                                    smoothed_confidence = progress * progress * (3 - 2 * progress)
                                    current_prediction = {
                                        'character': predicted_character,
                                        'time_left': max(0.0, round(time_left, 2)),
                                        'is_confirmed': False,
                                        'confidence': smoothed_confidence
                                    }
                            except Exception as e:
                                print(f"Prediction error: {str(e)}")
                                continue
            
            # Convert frame to bytes and yield
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    
    except Exception as e:
        print(f"Error in generate_frames: {str(e)}")
    finally:
        if cap is not None:
            cap.release()

@app.route('/video_feed')
def video_feed():
    try:
        return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')
    except Exception as e:
        print(f"Error in video_feed: {str(e)}")
        return "Error: Could not initialize video feed", 500

@app.route('/get_prediction')
def get_prediction():
    global current_prediction, confirmed_prediction
    if current_prediction is not None:
        prediction = current_prediction
        current_prediction = None
        return jsonify({'prediction': prediction})
    return jsonify({'prediction': None})

@app.route('/chat')
def chat():
    return render_template('chat.html')


videos = {
    'A': [
        {'url': 'https://videos.sproutvideo.com/embed/4498d3bc1215e0cecd/9a452ee5a9920103', 'title': 'A Little bit'},
        {'url': 'https://videos.sproutvideo.com/embed/7098d3bc1215e7c5f9/801abc57c895381d', 'title': 'A lot'},
        {'url': 'https://videos.sproutvideo.com/embed/1198d3bc1215e7c898/ebddae4a56fda859', 'title': 'About'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bc1215e6c025/7ea06aabb6df6a56', 'title': 'Above'},
        {'url': 'https://videos.sproutvideo.com/embed/a798d3bc1215e6c72e/8252fad30c30e6e3', 'title': 'Air Conditioner'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bc1215e5c325/c9c10b3044704409', 'title': 'Accident'},
        {'url': 'https://videos.sproutvideo.com/embed/1198d3bc1215e5ca98/8703d43c0c72da1e', 'title': 'Across'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bc1215e4c225/2d95206614896db5', 'title': 'Act'},
        {'url': 'https://videos.sproutvideo.com/embed/ea98d3bc1215e4c463/6e7d7e7430713b20', 'title': 'Action'},
        {'url': 'https://videos.sproutvideo.com/embed/7998d3bc1215ebccf0/dd895e550e874c7f', 'title': 'Add'},
        {'url': 'https://videos.sproutvideo.com/embed/a798d3bc1215ebca2e/a52a5b2d20ca3983', 'title': 'Address'},
        {'url': 'https://videos.sproutvideo.com/embed/d398d3bc1215eacf5a/d91b2f2385058298', 'title': 'Adult'},
        {'url': 'https://videos.sproutvideo.com/embed/ea98d3bc1215eaca63/a833778e18200edf', 'title': 'Advertisement'},
        {'url': 'https://videos.sproutvideo.com/embed/4d98d3bc1216e0c0c4/01966820f3a6a46c', 'title': 'Afraid'},
        {'url': 'https://videos.sproutvideo.com/embed/7998d3bc1216e1c5f0/2396f70b14d4bcdc', 'title': 'After'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bc1216e1c425/1446f76483ab4364', 'title': 'Afternoon'}
    ],
    'B': [
        {'url': 'https://videos.sproutvideo.com/embed/ea98d3bf191ee0c363/2de8b6008078aeff', 'title': 'Baby'},
        {'url': 'https://videos.sproutvideo.com/embed/0698d3bf191ee1c68f/fbd7954d14a2cbb8', 'title': 'Back'},
        {'url': 'https://videos.sproutvideo.com/embed/7098d3bf191ee1c0f9/416e0f1413b99901', 'title': 'BackPack'},
        {'url': 'https://videos.sproutvideo.com/embed/4498d3bf191ee1cccd/096323fe32785b5f', 'title': 'Bad'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bf191ee3c625/1fdbea956df99efe', 'title': 'Ball'},
        {'url': 'https://videos.sproutvideo.com/embed/d398d3bf191ee3c55a/affbfe668a27fd1c', 'title': 'Balloon'},
        {'url': 'https://videos.sproutvideo.com/embed/4d98d3bf191ee3c3c4/e3b1c9085b3019af', 'title': 'Banana'},
        {'url': 'https://videos.sproutvideo.com/embed/a798d3bf191ee4c62e/e4b5dc12eb3f68dd', 'title': 'Baseball'},
        {'url': 'https://videos.sproutvideo.com/embed/ea98d3bf191ee6c563/f56b500959e6b111', 'title': 'Bathroom'},
        {'url': 'https://videos.sproutvideo.com/embed/7998d3bf191ee7c3f0/01ad0f6e6b35e226', 'title': 'Beach'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bf191ee8cd25/564a0ed953b215e3', 'title': 'Beautiful'},
        {'url': 'https://videos.sproutvideo.com/embed/ac98d3bf191fe1c525/8c454f9938caa462', 'title': 'Before'},
        {'url': 'https://videos.sproutvideo.com/embed/ea98d3bf191fe5c763/2255026b1cd9f8af', 'title': 'Best'},
        {'url': 'https://videos.sproutvideo.com/embed/1198d3bf191fe4c998/625732e5866ca480', 'title': 'Big'},
        {'url': 'https://videos.sproutvideo.com/embed/1198d3bf191fe7ca98/65692172c7f64347', 'title': 'Black'},
        {'url': 'https://videos.sproutvideo.com/embed/0698d3bf191fe8ce8f/b906620f64a6db95', 'title': 'Blouse'}
    ],
    # Add more letters here following the same format
}

@app.route('/categories')
def categories():
    return render_template('categories.html')

@app.route('/videos/<letter>')
def get_videos(letter):
    return jsonify(videos.get(letter.upper(), []))


videos2 = [
    {'letter': 'A', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-591-1.mp4'},
    {'letter': 'B', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-592-1.mp4'},
    {'letter': 'C', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-593-1.mp4'},
    {'letter': 'D', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-594-1.mp4'},
    {'letter': 'E', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-595-1.mp4'},
    {'letter': 'F', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-596-1.mp4'},
    {'letter': 'G', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-597-1.mp4'},
    {'letter': 'H', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-598-1.mp4'},
    {'letter': 'I', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-599-1.mp4'},
    {'letter': 'J', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-600-1.mp4'},
    {'letter': 'K', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-601-1.mp4'},
    {'letter': 'L', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-602-1.mp4'},
    {'letter': 'M', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-603-1.mp4'},
    {'letter': 'N', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-604-1.mp4'},
    {'letter': 'O', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-605-1.mp4'},
    {'letter': 'P', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-606-1.mp4'},
    {'letter': 'Q', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-607-1.mp4'},
    {'letter': 'R', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-608-1.mp4'},
    {'letter': 'S', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-609-1.mp4'},
    {'letter': 'T', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-610-1.mp4'},
    {'letter': 'U', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-611-1.mp4'},
    {'letter': 'V', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-612-1.mp4'},
    {'letter': 'W', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-613-1.mp4'},
    {'letter': 'X', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-614-1.mp4'},
    {'letter': 'Y', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-615-1.mp4'},
    {'letter': 'Z', 'link': 'https://media.spreadthesign.com/video/mp4/13/alphabet-letter-616-1.mp4'}
]


@app.route("/FingerSpelling", methods=['GET', 'POST'])
def finger():
    selected_video = None
    if request.method == 'POST':
        selected_letter = request.form.get('selected_letter')
        selected_video = next((video for video in videos2 if video['letter'] == selected_letter), None)
    return render_template('FingerSpelling.html', videos2=videos2, selected_video=selected_video)

@app.route('/text-to-speech', methods=['POST'])
def text_to_speech():
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400

        # Create a bytes buffer to store audio data
        mp3_fp = io.BytesIO()
        
        # Generate speech directly to the buffer
        tts = gTTS(text=text, lang='en', slow=False)  # Added slow=False for normal speed
        tts.write_to_fp(mp3_fp)
        mp3_fp.seek(0)
        
        # Stream the audio data directly with proper headers
        response = send_file(
            mp3_fp,
            mimetype='audio/mpeg',
            as_attachment=False,
            download_name='speech.mp3'
        )
        
        # Add headers to prevent caching
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        
        return response

    except Exception as e:
        print(f"Text-to-speech error: {str(e)}")  # Add logging for debugging
        return jsonify({'error': str(e)}), 500

@app.route('/get-avatars')
def get_avatars():
    try:
        with open('avatars.txt', 'r', encoding='utf-8') as file:
            # Read all lines and filter out empty lines
            avatars = [line.strip() for line in file.readlines() if line.strip()]
            return jsonify({"avatars": avatars})
    except Exception as e:
        print(f"Error loading avatars: {str(e)}")
        return jsonify({"avatars": ["👤"]})

@app.route('/speech-to-text', methods=['POST'])
def speech_to_text():
    temp_dir = None
    try:
        if 'audio' not in request.files:
            print("No audio file in request")
            return jsonify({'error': 'No audio file provided'}), 400
        
        audio_file = request.files['audio']
        print(f"Received audio file: {audio_file.filename}, Content Type: {audio_file.content_type}")
        
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        temp_webm = os.path.join(temp_dir, 'temp_audio.webm')
        temp_wav = os.path.join(temp_dir, 'temp_audio.wav')
          # Save the uploaded WebM file
        audio_file.save(temp_webm)
        print(f"Saved WebM file to: {temp_webm}")
        
        # Convert WebM to WAV using pydub
        try:
            audio = AudioSegment.from_file(temp_webm, format="webm")
            audio.export(temp_wav, format="wav")
            print(f"Converted to WAV using pydub: {temp_wav}")
        except Exception as e:
            print(f"Pydub conversion error: {str(e)}")
            raise

        # Convert the audio to text
        with sr.AudioFile(temp_wav) as source:
            print("Reading audio file...")
            audio_data = recognizer.record(source)
            print("Recognizing speech...")
            text = recognizer.recognize_google(audio_data)
            print(f"Recognized text: {text}")
            
        return jsonify({'text': text})
        
    except sr.UnknownValueError:
        print("Speech Recognition could not understand audio")
        return jsonify({'error': 'Could not understand audio'}), 400
    except sr.RequestError as e:
        print(f"Could not request results from Speech Recognition service; {str(e)}")
        return jsonify({'error': 'Speech recognition service error'}), 500
    except Exception as e:
        print(f"Speech-to-text error: {str(e)}")
        return jsonify({'error': str(e)}), 500
    finally:
        # Clean up temporary files
        if temp_dir:
            try:
                for file in os.listdir(temp_dir):
                    os.remove(os.path.join(temp_dir, file))
                os.rmdir(temp_dir)
            except Exception as e:
                print(f"Error cleaning up temporary files: {str(e)}")

@app.before_request
def update_activity():
    # Update user activity on each request if user is logged in
    username = request.args.get('username') or request.form.get('username')
    if username and username in load_users().get('online_users', []):
        update_user_activity(username)

def add_user_to_online(username):
    try:
        with open('users.json', 'r') as f:
            data = json.load(f)
            if username not in data['online_users']:
                data['online_users'].append(username)
            # Update last activity time for the user
            if 'user_activity' not in data:
                data['user_activity'] = {}
            data['user_activity'][username] = time.time()
        with open('users.json', 'w') as f:
            json.dump(data, f, indent=4)
        return True
    except Exception as e:
        print(f"Error adding user to online list: {str(e)}")
        return False

def check_user_activity(username):
    try:
        with open('users.json', 'r') as f:
            data = json.load(f)
            # Get the last activity time for the user
            last_activity = data.get('user_activity', {}).get(username, 0)
            # If no activity in the last 8 seconds, consider user inactive
            return time.time() - last_activity < 8
    except Exception as e:
        print(f"Error checking user activity: {str(e)}")
        return False

def update_user_activity(username):
    try:
        data = safe_read_json('users.json')
        if 'user_activity' not in data:
            data['user_activity'] = {}
        data['user_activity'][username] = time.time()
        safe_write_json('users.json', data)
    except Exception as e:
        print(f"Error updating user activity: {str(e)}")

def remove_inactive_users():
    try:
        data = safe_read_json('users.json')
            
        # Check all online users
        inactive_users = []
        for username in data['online_users']:
            if not check_user_activity(username):
                inactive_users.append(username)
            else:
                # Update last activity time for active users
                update_user_activity(username)
            
        # Remove inactive users
        for username in inactive_users:
            if username in data['online_users']:
                data['online_users'].remove(username)
                print(f"Removed inactive user: {username}")
            
        # If any users were removed, save the changes
        if inactive_users:
            safe_write_json('users.json', data)
            
    except Exception as e:
        print(f"Error removing inactive users: {str(e)}")

# Schedule periodic check for inactive users
def start_inactive_users_checker():
    import threading
    import time
    
    def check_periodically():
        print("Starting inactive users checker...")
        while True:
            try:
                remove_inactive_users()
                time.sleep(5)  # Check every 30 seconds
            except Exception as e:
                print(f"Error in checker thread: {str(e)}")
                time.sleep(5)  # Wait a bit before retrying if there's an error
    
    checker_thread = threading.Thread(target=check_periodically)
    checker_thread.daemon = True
    checker_thread.start()
    print("Inactive users checker started")

@app.route('/api/get-online-users')
def get_online_users():
    try:
        data = safe_read_json('users.json')
        online_users = data.get('online_users', [])
        return jsonify({'online_users': online_users, 'count': len(online_users)})
    except Exception as e:
        print(f"Error getting online users: {str(e)}")
        return jsonify({'error': 'Could not retrieve online users'}), 500

def get_user_id(username):
    try:
        with open('users.json', 'r') as f:
            data = json.load(f)
            if username in data['users']:
                return data['users'][username].get('id')
    except Exception as e:
        print(f"Error getting user ID: {str(e)}")
    return None

def get_chat_id(user1_id, user2_id):
    """
    تقوم بإنشاء معرف المحادثة من خلال ترتيب IDs المستخدمين من الأصغر إلى الأكبر
    مثال: 
    get_chat_id("487", "1387") -> "487_1387"
    get_chat_id("1387", "487") -> "487_1387"
    """
    # تحويل IDs إلى أرقام للمقارنة
    id1 = int(user1_id)
    id2 = int(user2_id)
    # ترتيب IDs وإرجاع المعرف
    return f"{min(id1, id2)}_{max(id1, id2)}"

def save_video_call_message(sender, recipient, message):
    try:
        # التحقق من أن المرسل والمستلم مختلفان
        if sender == recipient:
            return False, "لا يمكنك إرسال رسائل لنفسك"

        print(f"Saving message - From: {sender}, To: {recipient}, Message: {message}")
        
        data = safe_read_json('users.json')
        
        # الحصول على IDs المستخدمين
        sender_id = data['users'].get(sender, {}).get('id')
        recipient_id = data['users'].get(recipient, {}).get('id')
        
        if not sender_id or not recipient_id:
            return False, "خطأ في العثور على المستخدمين"
        
        # تأكد من وجود قسم messages
        if 'messages' not in data:
            data['messages'] = {}
            
        # إنشاء معرف المحادثة
        chat_key = f"{min(sender_id, recipient_id)}_{max(sender_id, recipient_id)}"
        
        # إنشاء مصفوفة للمحادثة إذا لم تكن موجودة
        if chat_key not in data['messages']:
            data['messages'][chat_key] = []
            
        # إضافة الرسالة الجديدة
        message_data = {
            'sender': sender,
            'message': message,
            'timestamp': time.time(),
            'delivered': False,
            'read': False,
            'message_id': str(time.time()).replace('.', '')
        }
        data['messages'][chat_key].append(message_data)
        
        # حفظ التغييرات
        safe_write_json('users.json', data)
        print(f"Message saved successfully in chat {chat_key}: {message_data}")
        return True, "تم إرسال الرسالة بنجاح"
    except Exception as e:
        print(f"Error saving video call message: {str(e)}")
        return False, str(e)

def get_video_call_messages(user1, user2):
    try:
        data = safe_read_json('users.json')
        
        # الحصول على IDs المستخدمين
        user1_id = data['users'].get(user1, {}).get('id')
        user2_id = data['users'].get(user2, {}).get('id')
        
        if not user1_id or not user2_id:
            print(f"Error: Could not find user IDs for {user1} or {user2}")
            return []
            
        # إنشاء معرف المحادثة
        chat_key = f"{min(user1_id, user2_id)}_{max(user1_id, user2_id)}"
        print(f"Searching for chat with key: {chat_key}")
        
        # جمع الرسائل مع المعلومات الإضافية
        messages = data.get('messages', {}).get(chat_key, [])
        
        # تحديث حالة القراءة للرسائل
        if messages:
            modified = False
            for msg in messages:
                if msg['sender'] != user1 and not msg.get('read', False):
                    msg['read'] = True
                    modified = True
                if not msg.get('delivered', False):
                    msg['delivered'] = True
                    modified = True
            
            # حفظ التغييرات في حالة تم تعديل أي رسالة
            if modified:
                safe_write_json('users.json', data)
        
        return messages
    except Exception as e:
        print(f"Error getting video call messages: {str(e)}")
        return []

@app.route('/api/video-call/send-message', methods=['POST'])
def send_video_call_message():
    try:
        data = request.get_json()
        sender = data.get('sender')
        recipient = data.get('recipient')
        message = data.get('message')
        
        print(f"Received message request - From: {sender}, To: {recipient}, Message: {message}")
        
        if not all([sender, recipient, message]):
            return jsonify({'error': 'جميع الحقول مطلوبة'}), 400
            
        success, response_message = save_video_call_message(sender, recipient, message)
        if success:
            return jsonify({'success': True, 'message': response_message})
        else:
            return jsonify({'error': response_message}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/video-call/get-messages', methods=['GET'])
def get_video_call_messages_route():
    """
    الحصول على رسائل المحادثة بين مستخدمين
    """
    try:
        user1 = request.args.get('user1')
        user2 = request.args.get('user2')
        last_timestamp = float(request.args.get('lastTimestamp', 0))
        
        if not user1 or not user2:
            return jsonify({'error': 'يجب تحديد المستخدمين'}), 400
            
        messages = get_video_call_messages(user1, user2)
        # فلترة الرسائل الجديدة فقط
        new_messages = [msg for msg in messages if msg['timestamp'] > last_timestamp]
        
        return jsonify({
            'messages': new_messages,
            'timestamp': time.time()
        })
    except Exception as e:
        print(f"Error in get_video_call_messages_route: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat/selected-user', methods=['GET'])
def get_selected_chat_user():
    """
    الحصول على المستخدم المحدد للمحادثة
    """
    try:
        current_user = request.args.get('currentUser')
        if not current_user:
            return jsonify({'error': 'يجب تحديد المستخدم'}), 400
            
        data = safe_read_json('users.json')
        selected_user = data.get('selected_chats', {}).get(current_user)
        
        return jsonify({
            'selectedUser': selected_user
        })
    except Exception as e:
        print(f"Error in get_selected_chat_user: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat/select-user', methods=['POST'])
def select_chat_user():
    """
    تحديد مستخدم للمحادثة
    """
    try:
        data = request.get_json()
        current_user = data.get('currentUser')
        selected_user = data.get('selectedUser')
        
        if not current_user or not selected_user:
            return jsonify({'error': 'يجب تحديد المستخدمين'}), 400
            
        users_data = safe_read_json('users.json')
        
        # التحقق من وجود المستخدمين
        if current_user not in users_data['users'] or selected_user not in users_data['users']:
            return jsonify({'error': 'مستخدم غير موجود'}), 404
            
        if 'selected_chats' not in users_data:
            users_data['selected_chats'] = {}
            
        users_data['selected_chats'][current_user] = selected_user
        safe_write_json('users.json', users_data)
        
        return jsonify({
            'success': True,
            'message': f'تم اختيار {selected_user} للمحادثة'
        })
    except Exception as e:
        print(f"Error in select_chat_user: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    start_inactive_users_checker()  # Start the inactive users checker
    app.run(host='0.0.0.0', port=8000, debug=True)