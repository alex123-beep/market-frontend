function fetchVideos(letter) {
    fetch(`/videos/${letter}`)
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('video-container');
            container.innerHTML = '';
            data.forEach(video => {
                const videoElem = document.createElement('div');
                videoElem.className = 'video-item';
                videoElem.innerHTML = `<h3>${video.title}</h3><iframe src="${video.url}" frameborder="10" allowfullscreen></iframe>`;
                container.appendChild(videoElem);
            });
        })
        .catch(error => console.error('Error fetching videos:', error));
}

let selectedUser = null;
let lastMessageTimestamp = 0;
let updateInterval = null;

function selectChatUser(username) {
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    fetch('/api/select-chat-user', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            currentUser: currentUser,
            selectedUser: username
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            selectedUser = username;
            startMessageUpdates();
        }
    })
    .catch(error => console.error('Error selecting user:', error));
}

function startMessageUpdates() {
    // Clear any existing interval
    if (updateInterval) {
        clearInterval(updateInterval);
    }
    
    // Start new update interval
    updateInterval = setInterval(updateMessages, 1000); // Update every second
    
    // Initial update
    updateMessages();
}

function updateMessages() {
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    if (!selectedUser) return;
    
    fetch(`/api/get-chat-messages?currentUser=${currentUser}&selectedUser=${selectedUser}&lastTimestamp=${lastMessageTimestamp}`)
        .then(response => response.json())
        .then(data => {
            if (data.messages && data.messages.length > 0) {
                displayNewMessages(data.messages);
                lastMessageTimestamp = data.timestamp;
            }
        })
        .catch(error => console.error('Error updating messages:', error));
}

function displayNewMessages(messages) {
    const messageContainer = document.querySelector('.messages-container');
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    messages.forEach(message => {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${message.sender === currentUser ? 'sent' : 'received'}`;
        messageElement.innerHTML = `
            <span class="sender">${message.sender}</span>
            <p class="message-text">${message.message}</p>
            <span class="timestamp">${new Date(message.timestamp * 1000).toLocaleTimeString()}</span>
        `;
        messageContainer.appendChild(messageElement);
    });
    
    // Scroll to the bottom of the messages
    messageContainer.scrollTop = messageContainer.scrollHeight;
}


// ضع هذا الكود بعد التأكد من وجود اسم المستخدم في متغير username
function startUserPing(username) {
    setInterval(() => {
        fetch('/api/ping', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username })
        });
    }, 5000); // كل 5 ثوانٍ
}

// مثال: إذا كان لديك متغير username في الجافاسكريبت
// startUserPing(username);