// Variables to store WebSocket connection and video elements
let socket;
let video = null;
let isSignMode = true;

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', async () => {
    video = document.getElementById('video-feed');
    
    // Request camera access and start the video stream
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: {
                width: 640,
                height: 480
            }
        });
        video.srcObject = stream;
        video.play();
    } catch (err) {
        console.error('Error accessing camera:', err);
        alert('Could not access camera. Please make sure you have granted camera permissions.');
    }
    
    // Start checking for predictions
    setInterval(checkPrediction, 100); // Check every 100ms
});

// Function to get the current prediction
function checkPrediction() {
    if (!isSignMode) return;
    // Prediction functionality has been removed
}


// Update the prediction display on the page
function updatePredictionDisplay(prediction) {
    const predictionBox = document.getElementById('prediction-box');
    const confidenceMeter = document.getElementById('confidence-meter');
    
    if (predictionBox && prediction) {
        // Update the prediction display
        predictionBox.textContent = prediction.character;
        
        // Update the confidence meter if it exists
        if (confidenceMeter) {
            confidenceMeter.value = prediction.confidence;
        }
        
        // Add confirmed class if the prediction is confirmed
        if (prediction.is_confirmed) {
            predictionBox.classList.add('confirmed');
        } else {
            predictionBox.classList.remove('confirmed');
        }
    }
}

// Function to toggle between sign and speech modes
function toggleMode(mode) {
    isSignMode = mode === 'sign';
    fetch('/set_mode', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ mode: mode })
    });
}
