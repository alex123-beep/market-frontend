// Auto ping for index.html (Home)
document.addEventListener('DOMContentLoaded', function() {
    var loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        // Use the main ping function from activity.js if available
        if (typeof startUserPing === 'function') {
            startUserPing(loggedInUser);
        } else {
            // fallback: simple interval
            setInterval(function() {
                fetch('/api/ping', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: loggedInUser })
                });
            }, 5000);
        }
    }
});
