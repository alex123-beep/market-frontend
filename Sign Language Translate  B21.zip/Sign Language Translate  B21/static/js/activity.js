// دالة لإرسال ping للسيرفر
function startUserPing(username) {
    if (!username) {
        console.error('No username provided for ping');
        return;
    }
    
    // التأكد من عدم وجود interval سابق
    if (window.pingInterval) {
        clearInterval(window.pingInterval);
    }
    
    // إرسال ping كل 5 ثواني
    window.pingInterval = setInterval(() => {
        fetch('/api/ping', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username })
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                console.warn('Ping failed:', data.error);
            }
        })
        .catch(error => {
            console.error('Error sending ping:', error);
        });
    }, 5000);
    
    // إرسال ping مباشرة عند بدء التشغيل
    fetch('/api/ping', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username: username })
    })
    .catch(error => {
        console.error('Error sending initial ping:', error);
    });
}

// التوقف عن إرسال ping عند إغلاق الصفحة
window.addEventListener('beforeunload', () => {
    if (window.pingInterval) {
        clearInterval(window.pingInterval);
    }
});
