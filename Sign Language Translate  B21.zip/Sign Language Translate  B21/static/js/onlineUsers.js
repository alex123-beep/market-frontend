// Function to update the online users list
function updateOnlineUsers() {
    fetch('/api/get-online-users')
        .then(response => response.json())
        .then(data => {
            const userList = document.getElementById('userList');
            const onlineCount = document.getElementById('onlineCount');
            const userSearch = document.getElementById('userSearch');

            // Update online count
            onlineCount.textContent = `${data.count} Online`;

            // Clear current list
            userList.innerHTML = '';

            // Filter users based on search
            const searchTerm = userSearch.value.toLowerCase();
            const filteredUsers = data.online_users.filter(user => 
                user.toLowerCase().includes(searchTerm)
            );

            // Add users to the list
            filteredUsers.forEach(user => {
                const li = document.createElement('li');
                li.className = 'flex items-center p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200 user-item';
                li.setAttribute('data-username', user);
                li.innerHTML = `
                    <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                        ${user.charAt(0).toUpperCase()}
                    </div>
                    <span class="text-gray-800">${user}</span>
                    <span class="ml-auto">
                        <span class="inline-block w-2 h-2 bg-green-500 rounded-full"></span>
                    </span>
                `;
                li.addEventListener('click', () => selectChatUser(user));
                userList.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Error fetching online users:', error);
        });
}

let selectedUser = null;
let lastMessageTimestamp = 0;
let messageUpdateInterval = null;
let failedUpdateAttempts = 0;
const MAX_FAILED_ATTEMPTS = 3;

// التحقق من المستخدم المحدد عند تحميل الصفحة
function checkSelectedUser() {
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    fetch(`/api/get-selected-user?currentUser=${currentUser}`)
        .then(response => response.json())
        .then(data => {
            if (data.selectedUser) {
                selectedUser = data.selectedUser;
                const userItem = document.querySelector(`[data-username="${selectedUser}"]`);
                if (userItem) {
                    selectChatUser(selectedUser);
                }
            }
        })
        .catch(error => console.error('Error checking selected user:', error));
}

function selectChatUser(username) {
    // إزالة التحديد السابق
    document.querySelectorAll('.user-item').forEach(item => {
        item.classList.remove('selected');
    });
    
    // إضافة تحديد للمستخدم المختار
    const userItem = document.querySelector(`[data-username="${username}"]`);
    if (userItem) {
        userItem.classList.add('selected');
    }
    
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    fetch('/api/select-chat-user', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            currentUser: currentUser,
            selectedUser: username
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            selectedUser = username;
            document.getElementById('chattingWith').textContent = username;
            startMessageUpdates();
        }
    })
    .catch(error => console.error('Error selecting user:', error));
}

function startMessageUpdates() {
    // مسح أي تحديثات سابقة
    if (messageUpdateInterval) {
        clearInterval(messageUpdateInterval);
    }
    
    // إعادة تعيين المتغيرات
    lastMessageTimestamp = 0;
    failedUpdateAttempts = 0;
    
    // تنظيف حاوية الرسائل
    const messageContainer = document.querySelector('.messages-container');
    if (messageContainer) {
        messageContainer.innerHTML = '';
    }
    
    // تحديث فوري أول
    updateMessages();
    
    // بدء التحديثات الدورية
    messageUpdateInterval = setInterval(() => {
        if (failedUpdateAttempts >= MAX_FAILED_ATTEMPTS) {
            clearInterval(messageUpdateInterval);
            console.error('توقف التحديث التلقائي بسبب تكرار الفشل');
            return;
        }
        updateMessages();
    }, 1000);
}

function updateMessages() {
    if (!selectedUser) return;
    
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    fetch(`/api/video-call/get-messages?currentUser=${currentUser}&selectedUser=${selectedUser}&lastTimestamp=${lastMessageTimestamp}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            failedUpdateAttempts = 0; // إعادة تعيين العداد عند نجاح التحديث
            
            if (data.messages && data.messages.length > 0) {
                displayNewMessages(data.messages);
                lastMessageTimestamp = data.timestamp;
            }
        })
        .catch(error => {
            console.error('Error updating messages:', error);
            failedUpdateAttempts++;
            
            if (failedUpdateAttempts >= MAX_FAILED_ATTEMPTS) {
                clearInterval(messageUpdateInterval);
                console.error('توقف التحديث التلقائي بسبب تكرار الفشل');
            }
        });
}

function displayNewMessages(messages) {
    const messageContainer = document.querySelector('.messages-container');
    const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
    
    messages.forEach(message => {
        // التحقق من عدم وجود الرسالة مسبقاً
        const existingMessage = document.querySelector(`[data-message-id="${message.message_id}"]`);
        if (existingMessage) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = `message ${message.sender === currentUser ? 'sent' : 'received'}`;
        messageElement.setAttribute('data-message-id', message.message_id);
        
        messageElement.innerHTML = `
            <span class="sender">${message.sender}</span>
            <p class="message-text">${message.message}</p>
            <span class="timestamp">${new Date(message.timestamp * 1000).toLocaleTimeString()}</span>
        `;
        
        messageContainer.appendChild(messageElement);
    });
    
    // التمرير إلى آخر الرسائل
    messageContainer.scrollTop = messageContainer.scrollHeight;
}

function updateUserList() {
    fetch('/api/get-online-users')
        .then(response => response.json())
        .then(data => {
            const userList = document.getElementById('userList');
            const currentUser = document.querySelector('[data-current-user]').dataset.currentUser;
            
            // تخزين المستخدم المحدد حالياً
            const previouslySelected = selectedUser;
            
            userList.innerHTML = '';
            data.online_users.forEach(username => {
                if (username !== currentUser) {
                    userList.innerHTML += createUserListItem(username);
                }
            });
            
            document.getElementById('onlineCount').textContent = `${data.count} Online`;
            
            // إعادة تحديد المستخدم السابق إذا كان ما زال متصلاً
            if (previouslySelected) {
                const userItem = document.querySelector(`[data-username="${previouslySelected}"]`);
                if (userItem) {
                    userItem.classList.add('selected');
                } else {
                    // المستخدم غير متصل
                    selectedUser = null;
                    document.getElementById('chattingWith').textContent = 'User offline';
                    if (messageUpdateInterval) {
                        clearInterval(messageUpdateInterval);
                        messageUpdateInterval = null;
                    }
                }
            }
        })
        .catch(error => console.error('Error updating user list:', error));
}

// بدء التحديثات عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    checkSelectedUser(); // التحقق من المستخدم المحدد
    updateUserList(); // تحديث أولي
    setInterval(updateUserList, 5000); // تحديث قائمة المستخدمين كل 5 ثواني
    
    // إعداد خاصية البحث
    const searchInput = document.getElementById('userSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            document.querySelectorAll('.user-item').forEach(item => {
                const username = item.getAttribute('data-username').toLowerCase();
                item.style.display = username.includes(searchTerm) ? 'block' : 'none';
            });
        });
    }
});
