// Global variables for camera handling
let videoStream = null;
let canvas = null;
let isProcessing = false;
let checkPredictionInterval = null;
let isVideoActive = false;
let currentUsername = null;

// Initialize when document is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Get username from localStorage
    currentUsername = localStorage.getItem('loggedInUser');
    console.log('Camera handler initialized for user:', currentUsername);
});

// Initialize when document is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Camera handler initialized for user:', currentUsername);
});

// Function to start the camera and microphone
async function startCamera() {
    try {
        console.log('Starting camera...');
        if (!currentUsername) {
            console.error('Username not found');
            return;
        }

        // Request access to the user's camera and microphone
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: {
                width: { ideal: 640 },
                height: { ideal: 480 },
                facingMode: "user"
            },
            audio: true
        });

        // Get the video element and set its source to the camera stream
        const videoElement = document.getElementById('videoFeed');
        videoElement.srcObject = stream;
        videoStream = stream;
        isVideoActive = true;

        // Update the camera button
        const cameraButton = document.getElementById('cameraButton');
        cameraButton.innerHTML = '<i class="bi bi-camera-video-off-fill"></i> Stop Camera';
        cameraButton.classList.remove('bg-green-500', 'hover:bg-green-600');
        cameraButton.classList.add('bg-red-500', 'hover:bg-red-600');

        // Start prediction checking if in sign mode
        if (document.getElementById('commMode').value === 'sign') {
            startPredictionChecking();
        }

    } catch (err) {
        console.error('Error accessing camera or microphone:', err);
        let msg = 'لم أستطع الوصول للكاميرا أو المايكروفون. تأكد أنك وافقت على الإذن من المتصفح.';
        if (window.isSecureContext === false) {
            msg += '\nيجب تشغيل الموقع عبر https أو من خلال localhost أو عنوان IP محلي.';
        }
        alert(msg);
    }
}

// Function to stop the camera
function stopCamera() {
    if (videoStream) {
        console.log('Stopping camera...');
        // Stop all tracks in the stream
        videoStream.getTracks().forEach(track => track.stop());
        videoStream = null;
        
        // Clear the video element
        const videoElement = document.getElementById('videoFeed');
        videoElement.srcObject = null;
        isVideoActive = false;
        
        // Update the camera button
        const cameraButton = document.getElementById('cameraButton');
        cameraButton.innerHTML = '<i class="bi bi-camera-video-fill"></i> Start Camera';
        cameraButton.classList.remove('bg-red-500', 'hover:bg-red-600');
        cameraButton.classList.add('bg-green-500', 'hover:bg-green-600');
        
        // Stop prediction checking
        stopPredictionChecking();
        
        // Reset prediction display but keep the user selected
        document.getElementById('currentChar').textContent = '-';
        document.getElementById('timeLeft').textContent = '(camera off)';
    }
}

// Function to toggle camera
function toggleCamera() {
    if (isVideoActive) {
        stopCamera();
    } else {
        startCamera();
    }
}

// Function to handle mode changes
function handleModeChange(event) {
    const mode = event.target.value;
    const voiceControls = document.getElementById('voiceControls');
    
    if (mode === 'speech') {
        voiceControls.classList.remove('hidden');
        stopPredictionChecking();
    } else {
        voiceControls.classList.add('hidden');
        if (isVideoActive) {
            startPredictionChecking();
        }
    }
    
    // Send mode to server
    fetch('/set_mode', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ mode: mode })
    });
}

// Function to start checking for predictions
function startPredictionChecking() {
    if (!checkPredictionInterval) {
        checkPredictionInterval = setInterval(checkPrediction, 100); // Check every 100ms
    }
}

// Function to stop checking for predictions
function stopPredictionChecking() {
    if (checkPredictionInterval) {
        clearInterval(checkPredictionInterval);
        checkPredictionInterval = null;
    }
}

// Function to check prediction
function checkPrediction() {
    if (!isVideoActive) {
        console.log('Camera not active, skipping prediction');
        return;
    }

    const videoElement = document.getElementById('videoFeed');
    if (videoElement && videoElement.readyState === 4) {  // 4 = HAVE_ENOUGH_DATA
        processFrame(videoElement);
    } else {
        console.log('Video element not ready:', { 
            hasVideo: !!videoElement, 
            readyState: videoElement?.readyState 
        });
        document.getElementById('timeLeft').textContent = '(waiting...)';
        document.getElementById('currentChar').textContent = '-';
    }
}

// Function to start prediction polling
function startPredictionPolling() {
    console.log('Starting prediction polling');
    if (checkPredictionInterval) {
        clearInterval(checkPredictionInterval);
    }
    checkPredictionInterval = setInterval(checkPrediction, 200); // Check every 200ms
}

// Function to stop prediction polling
function stopPredictionPolling() {
    console.log('Stopping prediction polling');
    if (checkPredictionInterval) {
        clearInterval(checkPredictionInterval);
        checkPredictionInterval = null;
    }
}

// Function to process video frames
async function processFrame(videoElement) {
    if (!videoElement || isProcessing || !currentUsername) return;
    
    try {
        isProcessing = true;
        
        // Create canvas if not exists
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.width = videoElement.videoWidth || 640;
            canvas.height = videoElement.videoHeight || 480;
        }
        
        // Draw current video frame to canvas
        const context = canvas.getContext('2d');
        context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        
        // Convert canvas to blob
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg'));
        
        // Create form data
        const formData = new FormData();
        formData.append('image', blob, 'frame.jpg');
        formData.append('username', currentUsername);
        
        // Send to server
        const response = await fetch('/api/process-image', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Find or create processed image container
            let processedImageContainer = document.getElementById('processed-image-container');
            if (!processedImageContainer) {
                processedImageContainer = document.createElement('div');
                processedImageContainer.id = 'processed-image-container';
                processedImageContainer.style.position = 'relative';
                videoElement.parentNode.appendChild(processedImageContainer);
            }
            
            // Find or create processed image display
            processedImageDisplay = document.getElementById('processed-image');
            if (!processedImageDisplay) {
                processedImageDisplay = document.createElement('img');
                processedImageDisplay.id = 'processed-image';
                processedImageDisplay.style.width = '640px';
                processedImageDisplay.style.height = '480px';
                processedImageContainer.appendChild(processedImageDisplay);
            }
            
            // Display processed image
            processedImageDisplay.src = data.processed_image;
            
            // Update prediction UI with confirmation status
            const currentChar = document.getElementById('currentChar');
            const timeLeft = document.getElementById('timeLeft');
            const predictedText = document.getElementById('predictedText');
            
            if (data.has_hand) {
                if (data.prediction) {
                    currentChar.textContent = data.prediction;
                    
                    if (data.is_confirmed) {
                        // Prediction is confirmed
                        currentChar.style.color = '#3B82F6'; // Blue color for confirmed
                        timeLeft.textContent = '(confirmed)';
                        
                        // Add to accumulated text only when confirmed
                        if (!accumulatedText || accumulatedText.slice(-1) !== data.prediction) {
                            accumulatedText += data.prediction;
                            predictedText.textContent = accumulatedText;
                        }
                    } else {
                        // Show countdown for unconfirmed prediction
                        currentChar.style.color = '#9CA3AF'; // Gray color while waiting
                        timeLeft.textContent = `(${data.time_left}s)`;
                    }
                }
            } else {
                currentChar.textContent = '-';
                timeLeft.textContent = '(waiting...)';
            }
        }
        
    } catch (error) {
        console.error('Error processing frame:', error);
    } finally {
        isProcessing = false;
    }
}

// Add event listeners when the document is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add event listener for mode changes
    // Add event listener for mode changes
    const modeSelector = document.getElementById('commMode');
    if (modeSelector) {
        modeSelector.addEventListener('change', handleModeChange);
    }

    // Add event listener for camera toggle button
    const cameraButton = document.getElementById('cameraButton');
    if (cameraButton) {
        cameraButton.addEventListener('click', toggleCamera);
    }
});