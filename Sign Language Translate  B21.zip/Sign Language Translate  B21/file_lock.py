import json
from filelock import FileLock, Timeout

def safe_read_json(filename):
    lock = FileLock(filename + ".lock")
    try:
        with lock.acquire(timeout=10):
            try:
                with open(filename, 'r') as json_file:
                    return json.load(json_file)
            except (FileNotFoundError, json.JSONDecodeError):
                # إذا الملف غير موجود أو تالف، أنشئ هيكل بيانات جديد
                default_data = {
                    "online_users": [],
                    "users": {},
                    "user_activity": {},
                    "messages": {},
                    "selected_chats": {}
                }
                with open(filename, 'w') as json_file:
                    json.dump(default_data, json_file, indent=4)
                return default_data
    except Timeout:
        # إذا لم نستطع الحصول على القفل
        raise Exception("Timeout acquiring file lock for reading")
    

def safe_write_json(filename, data):
    lock = FileLock(filename + ".lock")
    cleaned_data = {
        "online_users": data.get("online_users", []),
        "users": data.get("users", {}),
        "user_activity": data.get("user_activity", {}),
        "messages": data.get("messages", {}),
        "selected_chats": data.get("selected_chats", {})
    }
    try:
        with lock.acquire(timeout=10):
            with open(filename, 'w') as json_file:
                json.dump(cleaned_data, json_file, indent=4)
        return True
    except Timeout:
        raise Exception("Timeout acquiring file lock for writing")
