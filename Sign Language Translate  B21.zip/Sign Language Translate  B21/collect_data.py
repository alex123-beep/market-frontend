import os
import cv2
import mediapipe as mp
import numpy as np
import pickle

DATA_DIR = './data'
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    static_image_mode=True,
    max_num_hands=1,
    min_detection_confidence=0.5)

# Initialize data collection variables
data = []
labels = []
for dir_ in range(37):  # 0-25 for A-Z, 26-35 for 0-9, 36 for space
    dirpath = os.path.join(DATA_DIR, str(dir_))
    if not os.path.exists(dirpath):
        os.makedirs(dirpath)

# Map numbers to characters for display
label_map = {
    **{i: chr(65 + i) for i in range(26)},  # A-Z
    **{i: str(i - 26) for i in range(26, 36)},  # 0-9
    36: 'space'  # Space
}

cap = cv2.VideoCapture(0)
dataset_size = 100  # Number of samples per class

for dir_idx in range(37):
    sample_count = 0
    
    # Show instruction
    while True:
        ret, frame = cap.read()
        if not ret:
            continue
            
        frame = cv2.flip(frame, 1)
        h, w, _ = frame.shape
        
        # Show instructions
        label = label_map[dir_idx]
        cv2.putText(frame, f'Prepare to show sign for: {label}', (20, 50), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(frame, 'Press "Q" when ready', (20, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        cv2.imshow('frame', frame)
        key = cv2.waitKey(1)
        if key == ord('q'):
            break
            
    print(f'Collecting data for {label}')
    
    while sample_count < dataset_size:
        ret, frame = cap.read()
        if not ret:
            continue
            
        frame = cv2.flip(frame, 1)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        results = hands.process(frame_rgb)
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw the landmarks
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                
                # Extract features (x, y coordinates)
                data_aux = []
                x_ = []
                y_ = []
                
                for landmark in hand_landmarks.landmark:
                    x_.append(landmark.x)
                    y_.append(landmark.y)
                
                # Normalize coordinates
                for landmark in hand_landmarks.landmark:
                    data_aux.append(landmark.x - min(x_))
                    data_aux.append(landmark.y - min(y_))
                
                # Save data
                data.append(data_aux)
                labels.append(dir_idx)
                sample_count += 1
                
                # Save progress
                cv2.putText(frame, f'Collecting {label}: {sample_count}/{dataset_size}',
                            (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        cv2.imshow('frame', frame)
        cv2.waitKey(1)

cap.release()
cv2.destroyAllWindows()

# Save the collected data
with open('data.pickle', 'wb') as f:
    pickle.dump({'data': data, 'labels': labels}, f)

print("Data collection completed and saved!")
